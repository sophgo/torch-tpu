#ifndef _BM1684_GMEM_H_
#define _BM1684_GMEM_H_
int bmdrv_bm1684_parse_reserved_mem_info(struct bm_device_info *bmdi);
#endif

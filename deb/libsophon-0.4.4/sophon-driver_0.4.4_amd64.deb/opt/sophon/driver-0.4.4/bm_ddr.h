#ifndef _BM_DDR_H_
#define _BM_DDR_H_

#include "bm1682_ddr.h"
#include "bm1684_ddr.h"

#endif
